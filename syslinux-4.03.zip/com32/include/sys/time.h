#ifndef _SYS_TIME_H
#define _SYS_TIME_H

/* empty */

#endif
